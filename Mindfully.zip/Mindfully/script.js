
// H4 animation 
$(document).ready(function(){
  const imgItems = $('.slider li').length;
  let imgIndex = 1;
  for (let i = 1; i <= imgItems; i++) {
    $('.pagination').append('<li><span class="fa fa-circle"></span></li>')
  }

  $('.ani').animate({ 
    padding: '5px 0px',
    fontSize: '50px'
  }, 1000);
  $('.slider li').hide();
  $('.slider li:first').show();
  $('.pagination li:first').css({'color': '#cd6e2e'});

  $('.pagination li').click(pagination);
  $('.right span').click(nextSlider);
  $('.left span').click(previousSlider);

  setInterval (() => {
    nextSlider();
  }, 5000);

  function nextSlider(){
    if (imgIndex >= imgItems) {
      imgIndex = 1;
    } else {
      imgIndex++;
    }
    $('.pagination li').css({'color': '#858585'});
    $('.pagination li:nth-child(' + imgIndex + ')').css({'color': '#cd6e2e'});
    $('.slider li').hide();
    $('.slider li:nth-child(' + imgIndex + ')').fadeIn();
  }

  function previousSlider(){
    if (imgIndex <= 1) {
      imgIndex = 3;
    } else {
      imgIndex--;
    }
    $('.pagination li').css({'color': '#858585'});
    $('.pagination li:nth-child(' + imgIndex + ')').css({'color': '#cd6e2e'});
    $('.slider li').hide();
    $('.slider li:nth-child(' + imgIndex + ')').fadeIn();
  }

  function pagination () {
    const paginationIndex = $(this).index()+1;
    $('.slider li').hide();
    $('.slider li:nth-child(' + paginationIndex + ')').fadeIn();
    $('.pagination li').css({'color': '#858585'});
    $(this).css({'color': '#cd6e2e'});
  
  }
  // Benefits container

  $('.accordion_box:first').addClass('active')
  $('.accordion_box:first').children('.acc_trigger').children('i').addClass('fa-minus')
  $('.accordion_box:first').children('.acc_trigger').addClass('selected').next('.acc_container').show()

  $('.acc_trigger').click(function(event){
    if($(this).hasClass('selected')){
      $(this).removeClass('selected');
      $(this).children('i').removeClass('fa-minus');
      $(this).next().slideUp();
      $(this).parent().removeClass('active');
    }else {
      $('.acc_trigger').removeClass('selected');
      $(this).addClass('selected');
      $('.acc_trigger').children('i').removeClass('fa-minus');
      $(this).children('i').addClass('fa-minus');
      $('.acc_trigger').next().slideUp();
      $(this).next().slideDown();
      $('.accordion_box').addClass('active');
    }
  });


// Open & close cart

const cartIcon = $("#cart-icon");
const cart = $(".cart");
const closeCart = $("#cart-close");

$(this).addEventListener("click", ()=> {
  $(this).classList.add("active");
});

$(this).addEventListener("click", ()=> {
  $(this).classList.remove("active");
});

// Start when the document is ready

if(document.readyState == "loading"){
  document.addEventListener('DOMContentLoaded', start);
} else {
  start();
}

// start
function start(){
  addEvents();
}
});
